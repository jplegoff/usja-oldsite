<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr-fr" lang="fr-fr" >
<head>

<script src="/templates/template-ia-1-5/mootools-smoothscroll.js" type="text/javascript"></script>
<script type="text/javascript">window.addEvent('load',function() { new SmoothScroll({ duration: 800 }); });</script>
  <base href="http://www.carquefou-football.com/index.php" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta name="robots" content="index, follow" />
  <meta name="keywords" content="USJA, CARQUEFOU, Football, foot, 44" />
  <meta name="description" content="L'USJA Carquefou Football, toutes les équipes de foot, les résultats, les actualités." />
  <meta name="generator" content="" />
  <title>USJA Carquefou Football</title>
  <link href="/index.php?format=feed&amp;type=rss" rel="alternate" type="application/rss+xml" title="RSS 2.0" />
  <link href="/index.php?format=feed&amp;type=atom" rel="alternate" type="application/atom+xml" title="Atom 1.0" />
  <link href="/templates/template-ia-1-5/favicon.ico" rel="shortcut icon" type="image/x-icon" />
  <link rel="stylesheet" href="/plugins/content/highslide/highslide.css" type="text/css" />
  <link rel="stylesheet" href="/plugins/content/highslide/config/css/highslide-sitestyles.css" type="text/css" />
  <link rel="stylesheet" href="/plugins/system/jcemediabox/css/jcemediabox.css?3ab6d4490e67378d035cce4c84ffa080" type="text/css" />
  <link rel="stylesheet" href="/plugins/system/jcemediabox/themes/squeeze/css/style.css?db43fb7bdf4b88f44190f82d817326e3" type="text/css" />
  <link rel="stylesheet" href="/modules/mod_jo_accordion/styles/Default.css" type="text/css" />
  <script type="text/javascript" src="/media/system/js/mootools.js"></script>
  <script type="text/javascript" src="/media/system/js/caption.js"></script>
  <script type="text/javascript" src="/plugins/system/flexiaccess/flexiaccess.js"></script>
  <script type="text/javascript" src="/plugins/content/highslide/highslide-full.packed.js"></script>
  <script type="text/javascript" src="/plugins/content/highslide/easing_equations.js"></script>
  <script type="text/javascript" src="/plugins/content/highslide/swfobject.js"></script>
  <script type="text/javascript" src="/plugins/content/highslide/language/en.js"></script>
  <script type="text/javascript" src="/plugins/content/highslide/config/js/highslide-sitesettings.js"></script>
  <script type="text/javascript" src="/plugins/system/jcemediabox/js/jcemediabox.js?2ee2100a9127451a41de5a4c2c62e127"></script>
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/dojo/1.5/dojo/dojo.xd.js"></script>
  <script type="text/javascript" src="/modules/mod_jo_accordion/js/jo_accordion.js"></script>
  <script type="text/javascript" src="/modules/mod_idslider/tmpl/mod_idslider_class.noobslide.js"></script>
  <script type="text/javascript">
hs.graphicsDir = '/plugins/content/highslide/graphics/';JCEMediaBox.init({popup:{width:"",height:"",legacy:0,lightbox:0,shadowbox:0,resize:1,icons:1,overlay:1,overlayopacity:0.8,overlaycolor:"#000000",fadespeed:500,scalespeed:500,hideobjects:0,scrolling:"fixed",close:2,labels:{'close':'Close','next':'Next','previous':'Previous','cancel':'Cancel','numbers':'{$current} of {$total}'},cookie_expiry:"",google_viewer:0},tooltip:{className:"tooltip",opacity:0.8,speed:150,position:"br",offsets:{x: 16, y: 16}},base:"/",imgpath:"plugins/system/jcemediabox/img",theme:"squeeze",themecustom:"",themepath:"plugins/system/jcemediabox/themes",mediafallback:0,mediaselector:"audio,video"});
  </script>

<link rel="stylesheet" href="/templates/template-ia-1-5/css/template.css" type="text/css" />

<!--[if IE 8]>
<link href="/templates/template-ia-1-5/css/ie8.css" rel="stylesheet" type="text/css" />
<![endif]-->
<!--[if IE 7]>
<link href="/templates/template-ia-1-5/css/ie7.css" rel="stylesheet" type="text/css" />
<![endif]-->
<!--[if IE 6]>
<link href="/templates/template-ia-1-5/css/ie6only.css" rel="stylesheet" type="text/css" />
<![endif]-->

<!-- Inclusion fichier classes IA -->
<!-- fin Inclusion fichier classes IA -->

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-21119386-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<meta name="google-site-verification" content="9j_YRp_wo1mzTOSxKHBha8g_UOWXBrutnXNXYf7TtDk" />

            <!-- gestion des buttons d'edition flexicontent -->
			 

<script type="text/javascript">
hs.addEventListener(window, "load", function() {
   // click the element virtually:
   document.getElementById("autoload").onclick();
});
</script>
            

<style type="text/css">
                div#cookieMessageContainer{
                    font:normal 12px/16px Arial,Verdana,sans-serif;
position:fixed;
       
                    z-index:999999;bottom: 0;
                    right:0;
                    margin:0 auto;
					padding: 5px;
                    -webkit-border-bottom-right-radius: 0px;
                    -webkit-border-bottom-left-radius: 0px;
                    -moz-border-radius-bottomright: 0px;
                    -moz-border-radius-bottomleft: 0px;
                    border-bottom-right-radius: 0px;
                    border-bottom-left-radius: 0px;
                    -webkit-border-top-right-radius: 0px;
                    -webkit-border-top-left-radius: 0px;
                    -moz-border-radius-topright: 0px;
                    -moz-border-radius-topleft: 0px;
                    border-top-right-radius: 0px;
                    border-top-left-radius: 0px
                }
                #cookieMessageContainer table, #cookieMessageContainer tr, #cookieMessageContainer td {border:0px !important}
                #cookieMessageText p,.accept{font:normal 12px/16px Arial,Verdana,sans-serif;margin:0;padding:0 0 6px;text-align:left;vertical-align:middle}
                .accept label{vertical-align:middle}
                #cookieMessageContainer .cookie_button{background: url(http://www.carquefou-football.com/plugins/system/EUCookieDirective/images/continue_button_green.png);text-shadow: #000000 0.1em 0.1em 0.2em; color: #ffffff; padding: 5px 12px;height: 14px;float: left;}
                #cookieMessageContainer table,#cookieMessageContainer td{margin:0;padding:0;vertical-align:middle}
                #cookieMessageAgreementForm{margin:0 0 0 10px}
                #cookieMessageInformationIcon{margin:0 10px 0 0;height:29px}
                #continue_button{vertical-align:middle;cursor:pointer;margin:0 0 0 10px}
                #info_icon{vertical-align:middle;margin:5px 0 0}
                #buttonbarContainer{height:29px;margin:0 0 -10px}
                input#AcceptCookies{margin:0 10px;vertical-align:middle}
                #cookieMessageContainer .messageTable {border:0px;border-spacing:0px;border-color:#1D1D1D;}
                #messageTable tr, #messageTable td {border:0px;cellspacing:0px;cellpadding:0px;background-color:#1D1D1D;}
                #cookieMessageText {color:#FFFFFF !important;}
                #cookieMessageText p, .accept {color:#FFFFFF !important;}
                .cookieMessageText {color:#FFFFFF !important;}
                p.cookieMessageText {color:#FFFFFF !important;}
				.accept {float: left;padding: 5px 6px 4px 15px;}
				a#cookieMessageDetailsLink {color:#FFFFFF !important;}
            </style>
</head>

<body id="page_bg">
      

<div id="wrapper">
<h1 class="logo"><span>USJA Carquefou Football - Le site officiel des Verts et Blancs</span><a href="http://www.carquefou-football.com/" title="Retour &agrave; la page d'accueil"><img src="/templates/template-ia-1-5/images/usja-carquefou-football.jpg" width="222" height="112" alt="USJA Football Carquefou" /></a></h1>
<a name="top" id="top"></a>
    <div id="maincolumn_full">
      <div class="nopad">
         <div id="insert">
                     		<div class="module_menu-h">
			<div>
				<div>
					<div>
											<ul class="menu"><li id="current" class="active item1"><a href="http://www.carquefou-football.com/"><span>Accueil</span></a></li><li class="item8"><span class="separator"><span>|</span></span></li><li class="item76"><a href="/devenir-partenaire.html"><span>Partenaire</span></a></li><li class="item104"><span class="separator"><span>|</span></span></li><li class="item10"><a href="/contact.html"><span>Contact</span></a></li></ul>					</div>
				</div>
			</div>
		</div>
	
         		<div id="centercol" class="pasFlexi">
                     
                     		<div class="module_pub-h">
			<div>
				<div>
					<div>
																</div>
				</div>
			</div>
		</div>
	                   
                     <div class="blog">

	<div>
		<div>
							<div style="width:100%;" class="article_column">
					
<div class="contentpaneopen">




<div>
<p><a href="http://atlantique.fff.fr/competitions/php/club/club_agenda.php?cl_no=1337" target="_blank"><img style="font-size: 1.1em;" src="/images/stories/DECO-ARTICLE/Saison_2014-2015/AGENDA4.jpg" alt="AGENDA4" width="290" height="84" /></a><span style="font-size: 1.1em;">&nbsp;</span><a href="http://atlantique.fff.fr/competitions/php/club/club_resultat.php?cl_no=1337" target="_blank"><img style="font-size: 1.1em;" src="/images/stories/DECO-ARTICLE/Saison_2014-2015/RESULTATS4.jpg" alt="RESULTATS4" width="290" height="84" /></a></p></div>



</div>
<span class="article_separator"></span>

<div class="contentpaneopen">




<div>
<p><a href="/la-boutique.html"><img src="/images/banners/boutique.png" alt="boutique" width="553" height="118" /></a></p></div>



</div>
<span class="article_separator"></span>

<div class="contentpaneopen-title">
		<div class="contentheading">
    <h2>
					Voeux 2017		     </h2>
	</div>
	
	
	
		</div>
<div class="contentpaneopen">




<div>
<p><a href="/images/carte_de_voeux_2017_v2_site.png" target="_blank" class="jcepopup"><img src="/images/carte_de_voeux_2017_v2_site.png" alt="carte de voeux 2017 v2 site" width="600" height="502" style="display: block; margin-left: auto; margin-right: auto;" /></a></p></div>



</div>
<span class="article_separator"></span>

<div class="contentpaneopen-title">
		<div class="contentheading">
    <h2>
					Bureau 2016 2017		     </h2>
	</div>
	
	
	
		</div>
<div class="contentpaneopen">




<div>
<p><span style="font-family: verdana,geneva;">Hier soir, le conseil d'administration a élu son nouveau bureau </span></p>
<ul>
<li><span style="font-family: verdana,geneva;">Président : Anthony RETIÈRE</span></li>
<li><span style="font-family: verdana,geneva;">Vice-Président : Laurent BENEC'H</span></li>
<li><span style="font-family: verdana,geneva;">Trésorier : Henri FROMENTIN</span></li>
<li><span style="font-family: verdana,geneva;">Trésorier adjoint : Guy LE MELLINER</span></li>
<li><span style="font-family: verdana,geneva;">Secrétaire : Gérard ESTÈVE</span></li>
<li><span style="font-family: verdana,geneva;">Secrétaire adjointe : Rozenn FADY<br /></span></li>
</ul>
<p><span style="font-family: verdana,geneva;"><a href="/component/jce/?view=popup&amp;tmpl=component" onclick="window.open(this.href+'&amp;img=images/stories/DECO-ARTICLE/Saison_2015-2016/thumbnails/thumbnails/Présidents.png&amp;title=','','scrollbars=yes,resizable=yes,location=yes,menubar=yes,status=yes,toolbar=yes,left=0,top=0');return false;"><img src="/images/stories/DECO-ARTICLE/Saison_2015-2016/thumbnails/thumbnails/Présidents.png" alt="Présidents" width="361" height="244" style="display: block; margin-left: auto; margin-right: auto;" /></a></span></p></div>



</div>
<span class="article_separator"></span>

<div class="contentpaneopen-title">
		<div class="contentheading">
    <h2>
					Retour sur l'assemblée générale		     </h2>
	</div>
	
	
	
		</div>
<div class="contentpaneopen">




<div>
<p>Un grand merci à tous les adhérents qui se sont déplacés ou ont donné pouvoir.</p>
<p>Lors de cette AG, Gilles Fourage co-président en fin de mandat, a annoncé qu'il ne renouvellait pas son mandat, pour des raisons d'éloignement géographique futur.</p>
<p>Nous avons procédé à l'élection ou au renouvellement de 8 administrateurs.</p>
<p>Le prochain conseil d'administration&nbsp; élira le bureau de l'USJA pour la saison 2016-2017.</p>
<p>Retour en images :</p>
</div>


	<div class="suite">
		<a href="/le-club/actualites/1375-ag2016retour.html" class="readon" title="Suite de l'article Retour sur l'assemblée générale">
			Lire la suite...</a>
	</div>

</div>
<span class="article_separator"></span>
				</div>
				
		</div>
	</div>

</div>


                     
                     <div class="bottom">
	                     		<div class="module_pub-h">
			<div>
				<div>
					<div>
											<div style="position:relative; overflow:hidden; margin:0 auto; width:600px; height:112px">
	<div id="div5890b7af063df" style="position:absolute;">
<span style="display:block; float:left; width:600px; height:112px"><a href="/component/banners/click/16.html" target="_blank"><img src="/images/banners/ban_oriflamme-cliquez-pub.gif" alt="" /></a></span>
	</div>
</div>



<!--Javascript for slider initiation-->
<script type="text/javascript">
var var5890b7af06425 = new noobSlide({
box: $('div5890b7af063df'),
items: [1],
size: 600,
mode: 'horizontal',
mode_dir: 'left',
interval: 10000,


fxOptions: { duration: 1000, transition: Fx.Transitions.Back.easeOut },
startItem: 0,
autoPlay: true});
</script>
					</div>
				</div>
			</div>
		</div>
			<div class="module_title">
			<div>
				<div>
					<div>
											



{loadposition connexion}					</div>
				</div>
			</div>
		</div>
			<div class="module_club">
			<div>
				<div>
					<div>
																</div>
				</div>
			</div>
		</div>
			<div class="module_match">
			<div>
				<div>
					<div>
													<h3>Prochains événements</h3>
											<p class="eventlistmod_match">No current events.</p>					</div>
				</div>
			</div>
		</div>
			<div class="module_news">
			<div>
				<div>
					<div>
													<h3>Les News</h3>
											<ul class="newsbox_news">
	<li class="newsbox_news">
    <div class="date">31/12</div>		<a href="/le-club/actualites/1379-voeux2017.html" class="newsbox_news">Voeux 2017</a>
	</li>
	<li class="newsbox_news">
    <div class="date">14/12</div>		<a href="/le-club/actualites/1377-bureau20162017.html" class="newsbox_news">Bureau 2016 2017</a>
	</li>
	<li class="newsbox_news">
    <div class="date">03/12</div>		<a href="/le-club/actualites/1375-ag2016retour.html" class="newsbox_news">Retour sur l'assemblée générale</a>
	</li>
	<li class="newsbox_news">
    <div class="date">26/11</div>		<a href="/le-club/actualites/1371-ag2016.html" class="newsbox_news">Assemblée Générale</a>
	</li>
	<li class="newsbox_news">
    <div class="date">24/11</div>		<a href="/le-club/actualites/1373-gambardellafctours.html" class="newsbox_news">U19 - Gambardella</a>
	</li>
	<li class="newsbox_news">
    <div class="date">16/11</div>		<a href="/le-club/actualites/1365-info-feuille-de-match.html" class="newsbox_news">Information sur la feuille de match</a>
	</li>
</ul>
					</div>
				</div>
			</div>
		</div>
			<div class="module_pub-b">
			<div>
				<div>
					<div>
											<div style="position:relative; overflow:hidden; margin:0 auto; width:600px; height:112px">
	<div id="div5890b7af0e8ed" style="position:absolute;">
<span style="display:block; float:left; width:600px; height:112px"><a href="/component/banners/click/7.html" target="_blank"><img src="/images/banners/bandeau-pub-test.jpg" alt="" /></a></span>
	</div>
</div>



<!--Javascript for slider initiation-->
<script type="text/javascript">
var var5890b7af0e93d = new noobSlide({
box: $('div5890b7af0e8ed'),
items: [1],
size: 600,
mode: 'horizontal',
mode_dir: 'left',
interval: 10000,


fxOptions: { duration: 1000, transition: Fx.Transitions.Back.easeOut },
startItem: 0,
autoPlay: true});
</script>
					</div>
				</div>
			</div>
		</div>
	
                     </div>
                     
				</div>
                   <div id="leftcolumn">
                       		<div class="module_menu-g">
			<div>
				<div>
					<div>
											<dl class="level0" id="jo_accordion"><dt class="level0 jo-nav-33 parent"><span class="separator"><span>Le club</span></span></dt><dd class="level0 jo-nav-33 parent"><dl class="level1"><dt class="level1 jo-nav-20"><a href="/le-club/actualites.html"><span>Actualités</span></a></dt><dd class="level1 jo-nav-20" /><dt class="level1 jo-nav-34"><a href="/le-club/presentation.html"><span>Présentation</span></a></dt><dd class="level1 jo-nav-34" /><dt class="level1 jo-nav-38"><a href="/le-club/le-mot-des-presidents.html"><span>Le mot des Présidents</span></a></dt><dd class="level1 jo-nav-38" /><dt class="level1 jo-nav-100"><a href="/le-club/organigramme-sportif.html"><span>Organigramme sportif</span></a></dt><dd class="level1 jo-nav-100" /><dt class="level1 jo-nav-39"><a href="/le-club/conseil-dadministration.html"><span>Conseil d'administration</span></a></dt><dd class="level1 jo-nav-39" /><dt class="level1 jo-nav-40"><a href="/le-club/les-arbitres.html"><span>Les arbitres</span></a></dt><dd class="level1 jo-nav-40" /><dt class="level1 jo-nav-123"><a href="/le-club/reglement-interieur.html"><span>Règlement Intérieur</span></a></dt><dd class="level1 jo-nav-123" /><dt class="level1 jo-nav-158"><a href="/le-club/charte-educateur.html"><span>La charte de l'éducateur</span></a></dt><dd class="level1 jo-nav-158" /><dt class="level1 jo-nav-159"><a href="/le-club/charte-joueur.html"><span>La charte du joueur</span></a></dt><dd class="level1 jo-nav-159" /><dt class="level1 jo-nav-160"><a href="/le-club/charte-parents.html"><span>La charte des parents</span></a></dt><dd class="level1 jo-nav-160" /><dt class="level1 jo-nav-161"><a href="/le-club/inscriptions-reinscriptions.html"><span>Inscriptions/Réinscriptions</span></a></dt><dd class="level1 jo-nav-161" /></dl></dd><dt class="level0 jo-nav-45 parent"><span class="separator"><span>D.S.R.</span></span></dt><dd class="level0 jo-nav-45 parent"><dl class="level1"><dt class="level1 jo-nav-49"><a href="/division-regionale-superieure/mot-de-lentraineur.html"><span>Présentation</span></a></dt><dd class="level1 jo-nav-49" /><dt class="level1 jo-nav-92"><a href="http://atlantique.fff.fr/competitions/php/championnat/championnat_calendrier_resultat.php?cp_no=329603&amp;ph_no=1&amp;gp_no=1&amp;sa_no=2016&amp;typ_rech=equipe&amp;cl_no=1337&amp;eq_no=1&amp;type_match=deux&amp;lieu_match=deux" target="_blank"><span>Calendrier des Matchs</span></a></dt><dd class="level1 jo-nav-92" /><dt class="level1 jo-nav-114"><a href="http://atlantique.fff.fr/competitions/php/championnat/championnat_resultat.php?cp_no=329603&amp;ph_no=1&amp;sa_no=&amp;gp_no=1" target="_blank"><span>Classement et résultats</span></a></dt><dd class="level1 jo-nav-114" /></dl></dd><dt class="level0 jo-nav-149 parent"><span class="separator"><span>Pôle Post Formation</span></span></dt><dd class="level0 jo-nav-149 parent"><dl class="level1"><dt class="level1 jo-nav-52"><a href="/post-formation/seniors-b.html"><span>DH/DSR/1ere Div./U19 Elite</span></a></dt><dd class="level1 jo-nav-52" /></dl></dd><dt class="level0 jo-nav-12 parent"><span class="separator"><span>Pôle Formation</span></span></dt><dd class="level0 jo-nav-12 parent"><dl class="level1"><dt class="level1 jo-nav-143"><a href="/formation/u17-u16.html"><span>U18 U17 U16</span></a></dt><dd class="level1 jo-nav-143" /></dl></dd><dt class="level0 jo-nav-150 parent"><span class="separator"><span>Pôle Pré-formation</span></span></dt><dd class="level0 jo-nav-150 parent"><dl class="level1"><dt class="level1 jo-nav-144"><a href="/preformation/u15-u14.html"><span>Jeu à 11 - U15 U14</span></a></dt><dd class="level1 jo-nav-144" /><dt class="level1 jo-nav-66"><a href="/preformation/u12-u13.html"><span>Jeu à 8 - U13 U12</span></a></dt><dd class="level1 jo-nav-66" /></dl></dd><dt class="level0 jo-nav-151 parent"><span class="separator"><span>Pôle Animation</span></span></dt><dd class="level0 jo-nav-151 parent"><dl class="level1"><dt class="level1 jo-nav-67"><a href="/animation/u10-u11.html"><span>U11 U10</span></a></dt><dd class="level1 jo-nav-67" /><dt class="level1 jo-nav-68"><a href="/animation/u7-u8-u9.html"><span>U9 U8 U7</span></a></dt><dd class="level1 jo-nav-68" /></dl></dd><dt class="level0 jo-nav-139 parent"><span class="separator"><span>Loisirs et Vétérans</span></span></dt><dd class="level0 jo-nav-139 parent"><dl class="level1"><dt class="level1 jo-nav-69"><a href="/2014-08-19-07-30-34/loisirs.html"><span>Loisirs</span></a></dt><dd class="level1 jo-nav-69" /><dt class="level1 jo-nav-70"><a href="/2014-08-19-07-30-34/veterans-a.html"><span>Vétérans A</span></a></dt><dd class="level1 jo-nav-70" /><dt class="level1 jo-nav-71"><a href="/2014-08-19-07-30-34/veterans-b.html"><span>Vétérans B</span></a></dt><dd class="level1 jo-nav-71" /></dl></dd><dt class="level0 jo-nav-155 parent"><a href="/arbitrage.html"><span>Pôle Arbitrage</span></a></dt><dd class="level0 jo-nav-155 parent"><dl class="level1"><dt class="level1 jo-nav-125"><a href="/arbitrage/delegue-de-terrain.html"><span>Délégué de terrain</span></a></dt><dd class="level1 jo-nav-125" /><dt class="level1 jo-nav-126"><a href="/arbitrage/remplir-une-feuille-de-match.html"><span>Remplir une feuille de match</span></a></dt><dd class="level1 jo-nav-126" /></dl></dd><dt class="level0 jo-nav-154 parent"><a href="/2015-10-20-15-03-56.html"><span>Pôle Médical</span></a></dt><dd class="level0 jo-nav-154 parent"><dl class="level1"><dt class="level1 jo-nav-156"><a href="/2015-10-20-15-03-56/maladie-de-sever.html"><span>Maladie de Sever</span></a></dt><dd class="level1 jo-nav-156" /><dt class="level1 jo-nav-157"><a href="/2015-10-20-15-03-56/osgood.html"><span>Osgood Schlatter</span></a></dt><dd class="level1 jo-nav-157" /></dl></dd><dt class="level0 jo-nav-23"><a href="/tournoi.html"><span>Tournoi USJA Jeunes</span></a></dt><dd class="level0 jo-nav-23" /><dt class="level0 jo-nav-80 parent"><span class="separator"><span>Convocations</span></span></dt><dd class="level0 jo-nav-80 parent"><dl class="level1"><dt class="level1 jo-nav-111"><a href="/convocations/seniors.html"><span>Séniors</span></a></dt><dd class="level1 jo-nav-111" /><dt class="level1 jo-nav-99"><a href="/convocations/u18-u19.html"><span>U18 U19</span></a></dt><dd class="level1 jo-nav-99" /><dt class="level1 jo-nav-98"><a href="/convocations/u16-u17.html"><span>U16 U17</span></a></dt><dd class="level1 jo-nav-98" /><dt class="level1 jo-nav-97"><a href="/convocations/u14-u15.html"><span>U14 U15</span></a></dt><dd class="level1 jo-nav-97" /><dt class="level1 jo-nav-83"><a href="/convocations/u12-u13.html"><span>U12 U13</span></a></dt><dd class="level1 jo-nav-83" /><dt class="level1 jo-nav-95"><a href="/convocations/u10-u11.html"><span>U10 U11</span></a></dt><dd class="level1 jo-nav-95" /><dt class="level1 jo-nav-96"><a href="/convocations/u7-u8-u9.html"><span>U7 U8 U9</span></a></dt><dd class="level1 jo-nav-96" /></dl></dd><dt class="level0 jo-nav-148"><a href="/la-boutique.html"><span>La Boutique</span></a></dt><dd class="level0 jo-nav-148" /><dt class="level0 jo-nav-24"><a href="/stages.html"><span>Stages Vacances</span></a></dt><dd class="level0 jo-nav-24" /><dt class="level0 jo-nav-25"><a href="/pole-regional-excellence.html"><span>Pôle Régional Excellence</span></a></dt><dd class="level0 jo-nav-25" /></dl><img style="display:none;" src="/modules/mod_jo_accordion/images/open.gif" onload="javascript:dojo.addOnLoad(function(){var accordion = new JOAccordion({node : dojo.byId('jo-accordion'), mode: 'onclick', interval: '500', level : 0})});">					</div>
				</div>
			</div>
		</div>
			<div class="module_actu">
			<div>
				<div>
					<div>
													<h3>INFO FLASH</h3>
											
<ul class="vert_actu"><li>


<p><span style="background-color: #ffff00;">La boutique est ouverte tous les mercredis de 17h30 à 19h30</span></p>
<p><span style="background-color: #ffff00;">Pensez à commander pour vos cadeaux de Noêl !</span></p></li></ul>					</div>
				</div>
			</div>
		</div>
			<div class="module_pub-l">
			<div>
				<div>
					<div>
											<div style="position:relative; overflow:hidden; margin:0 auto; width:208px; height:190px">
	<div id="div5890b7af03e6d" style="position:absolute;">
<span style="display:block; float:left; width:208px; height:190px"><a href="/component/banners/click/22.html" target="_blank"><img src="/images/banners/ban_altarea cogedim.jpg" alt="" /></a></span>
	</div>
</div>



<!--Javascript for slider initiation-->
<script type="text/javascript">
var var5890b7af03eab = new noobSlide({
box: $('div5890b7af03e6d'),
items: [1],
size: 190,
mode: 'vertical',
mode_dir: 'top',
interval: 10000,


fxOptions: { duration: 1000, transition: Fx.Transitions.Back.easeOut },
startItem: 0,
autoPlay: true});
</script>
					</div>
				</div>
			</div>
		</div>
			<div class="module_boutique">
			<div>
				<div>
					<div>
											<a title="Accedez à la boutique de l'USJA Carquefou Football" href="/liens-vers-la-boutique.html">LA BOUTIQUE</a>					</div>
				</div>
			</div>
		</div>
			<div class="module_fb">
			<div>
				<div>
					<div>
											<h3><a href="http://www.facebook.com/pages/USJA-Carquefou-Football/133043343420049" target="_blank" title="Suivez-nous sur Facebook !">Suivez-nous sur <span>Facebook</span> !</a></h3>
<div class="fb-like-box" data-href="https://www.facebook.com/pages/USJA-Carquefou-Football/133043343420049" data-width="197" data-height="230" data-show-faces="true" data-stream="false" data-header="false" data-border-color="#ffffff"></div>					</div>
				</div>
			</div>
		</div>
			<div class="module_pub-l">
			<div>
				<div>
					<div>
											<div style="position:relative; overflow:hidden; margin:0 auto; width:208px; height:190px">
	<div id="div5890b7af05095" style="position:absolute;">
<span style="display:block; float:left; width:208px; height:190px"><a href="/component/banners/click/11.html" target="_blank"><img src="/images/banners/logo-vincent guerlais 2.jpg" alt="" /></a></span>
	</div>
</div>



<!--Javascript for slider initiation-->
<script type="text/javascript">
var var5890b7af050ec = new noobSlide({
box: $('div5890b7af05095'),
items: [1],
size: 190,
mode: 'vertical',
mode_dir: 'top',
interval: 10000,


fxOptions: { duration: 1000, transition: Fx.Transitions.Back.easeOut },
startItem: 0,
autoPlay: true});
</script>
					</div>
				</div>
			</div>
		</div>
			<div class="module_contact">
			<div>
				<div>
					<div>
											<p><strong>USJA Football Carquefou </strong></p>
<p>Stade du Moulin Boisseau</p>
<p>44470 CARQUEFOU</p>
<p>Tél : 02 40 52 70 04</p>
<p>info@carquefou-football.com</p>
<p class="acces">Plan d'accès</p>
<a href="/contact.html"><img alt="acces-au-plan" src="/images/stories/DECO-ARTICLE/acces-au-plan.jpg" height="47" width="189" /></a>					</div>
				</div>
			</div>
		</div>
	
                   </div>
                   
        </div>
                                 
        <div id="rightcolumn">
          		<div class="module_partenaires">
			<div>
				<div>
					<div>
											
<ul class="vert_partenaires">
		<li>
		


<p><a target="_blank" href="http://www.acttif.com/"><img alt="Logo_ACTTIF" src="/images/stories/PARTENAIRES/Logo_ACTTIF.jpg" height="64" width="110" /></a></p>	</li>
		<li>
		


<p><a target="_blank" href="http://www.art-dan.fr/"><img alt="LOGO_Art_Dan_internet" src="/images/stories/PARTENAIRES/LOGO_Art_Dan_internet.jpg" width="94" height="38" /></a></p>	</li>
		<li>
		


<p><a target="_blank" href="http://www.carquefou.fr/"><img alt="carquefou" src="/images/stories/PARTENAIRES/carquefou.jpg" width="98" height="79" /></a></p>	</li>
		<li>
		


<p><a target="_blank" href="https://www.creditmutuel.fr/groupe/fr/index.html"><img alt="credit-mutuel" src="/images/stories/PARTENAIRES/credit-mutuel.jpg" width="99" height="24" /></a></p>	</li>
		<li>
		


<p><a target="_blank" href="http://www.jacquesmetayimmobilier.fr/"><img alt="jacques-metay" src="/images/stories/PARTENAIRES/jacques-metay.jpg" width="85" height="94" /></a></p>	</li>
		<li>
		


<p><a target="_blank" href="http://www.jaulin-paysages.com/groupe-jcp-environnement/"><img alt="Logo_Groupe_JCP" src="/images/stories/PARTENAIRES/Logo_Groupe_JCP.png" height="78" width="110" /></a></p>	</li>
		<li>
		


<p><a target="_blank" href="http://www.inextenso.fr/Accueil"><img alt="logo_In_Extenso_2013" src="/images/stories/PARTENAIRES/logo_In_Extenso_2013.jpg" height="35" width="110" /></a></p>	</li>
		<li>
		


<p><a target="_blank" href="http://www.kappastore.fr/"><img alt="Logo_KAPPA" src="/images/stories/PARTENAIRES/Logo_KAPPA.jpg" height="36" width="100" /></a></p>	</li>
		<li>
		


<p><a target="_blank" href="http://www.loire-atlantique.fr"><img alt="Logo_CG_44" src="/images/stories/PARTENAIRES/Logo_CG_44.png" height="50" width="100" /></a></p>	</li>
		<li>
		


<p><a target="_blank" href="http://www.lod44.com/"><img alt="logo_Ocean_Dvt" src="/images/stories/PARTENAIRES/logo_Ocean_Dvt.jpg" height="52" width="119" /></a></p>	</li>
		<li>
		


<p><a target="_blank" href="http://www.presseocean.fr/"><img alt="presse-ocean" src="/images/stories/PARTENAIRES/presse-ocean.jpg" width="99" height="19" /></a></p>	</li>
		<li>
		


<p><a target="_blank" href="http://www.pepinieres-valderdre.fr/"><img alt="Logo_pepiniere_val_d_erdre_petit" src="/images/stories/PARTENAIRES/Logo_pepiniere_val_d_erdre_petit.jpg" width="86" height="27" /></a></p>	</li>
		<li>
		


<p><a target="_blank" href="http://www.paysdelaloire.fr/"><img alt="Logo_Conseil_Rgional_des_Pays_de_la_Loire" src="/images/stories/PARTENAIRES/Logo_Conseil_Rgional_des_Pays_de_la_Loire.png" height="38" width="110" /></a></p>	</li>
		<li>
		


<p><a target="_blank" href="http://www.magasins-u.com/superu-carquefou"><img alt="Logo_Super_U_Carquefou" src="/images/stories/PARTENAIRES/Logo_Super_U_Carquefou.png" height="45" width="110" /></a></p>	</li>
		<li>
		


<p><a target="_blank" href="http://www.magasins-u.com/portailu/national/supermarche-hypermarche-u"><img alt="u-les-nouveaux-commercants" src="/images/stories/PARTENAIRES/u-les-nouveaux-commercants.jpg" width="69" height="86" /></a></p>	</li>
		<li>
		


<p><img alt="Logo_Urbareva" src="/images/stories/PARTENAIRES/Logo_Urbareva.png" height="51" width="110" /></p>	</li>
	</ul>
					</div>
				</div>
			</div>
		</div>
			<div class="module_devenir">
			<div>
				<div>
					<div>
											<p style="text-align: center;"><a href="/lien-vers-devenir-partenaire.html"><img alt="Devenir partenaire de l'USJA Carquefou Football" src="/images/stories/DECO-ARTICLE/devenir-partenaire.jpg" height="152" width="113" /></a><br /><br /></p>					</div>
				</div>
			</div>
		</div>
	
        </div>
      </div>

    <div id="teb">
             <a href="#top" class="anchor">Haut de page</a>
             		<div class="moduletable">
					<ul class="menu"><li class="item17"><span class="separator"><span>|</span></span></li><li class="item19"><a href="/mentions-legales.html"><span>Mentions légales</span></a></li><li class="item18"><span class="separator"><span>|</span></span></li><li class="item15"><a href="/contact.html"><span>Contact</span></a></li><li class="item91"><span class="separator"><span>|</span></span></li><li class="item90"><a href="/staff.html"><span>Staff</span></a></li></ul>		</div>
	
             <a href="http://www.images-associees.com" target="_blank" class="ia" title="Images Associ&eacute;es, cr&eacute;ation de site internet &agrave; Nantes - 44">cr&eacute;ation internet : images-associees.com</a>
    </div>
    
   </div>
            
    
    <div id="header">
          <p>02 40 52 70 04</p>
    </div>

</div>
  

<noscript>
<ul class="noscript">
  <li>Ce site n&eacute;cessite JavaScript afin de fonctionner correctement. Merci de l&#039;activer dans votre navigateur.</li>
</ul>
</noscript>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/fr_FR/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div id="cookieMessageOuter" style="width:100%"><div id="cookieMessageContainer" style="width:100%;background-color:#1D1D1D;color:#fff"><table width="100%"><tr><td colspan="2"><div id="cookieMessageText" style="padding:6px 10px 0 15px;"><p style="color:#fff;">Nous utilisons des cookies pour vous garantir la meilleure expérience sur notre site. Si vous continuez à utiliser ce dernier, nous considérerons que vous acceptez l'utilisation des cookies. Pour en savoir plus <a id="cookieMessageDetailsLink" style="color:#fff; text-decoration: underline;" title="Pour en savoir plus" href="http://www.carquefou-football.com/mentions-legales.html#cookies">Mentions légales</a>.</p></div></td></tr><tr><td><span class="accept"><span class="cookieMessageText">J'accepte les cookies pour ce site internet</span></span></label> <div border="0" class="cookie_button" id="continue_button" onclick="SetCookie('cookieAcceptanceCookie','accepted',9999);">J'accepte</div></p></td><td align="right"></td></tr></table></div></div><script type="text/javascript" src="http://www.carquefou-football.com/plugins/system/EUCookieDirective/EUCookieDirective.js"></script>
</body>
</html>
